// ماي شات — عامل الخدمة: إشعارات + عمل بدون إنترنت
importScripts('https://cdn.onesignal.com/sdks/web/v16/OneSignalSDK.sw.js');
const VER='mychat-v10';
const SHELL=['/','/index.html','/manifest.json','/icon-192.png','/icon-512.png','/apple-touch-icon.png'];
self.addEventListener('install',e=>{
  e.waitUntil(caches.open(VER).then(c=>Promise.all(SHELL.map(u=>c.add(u).catch(()=>{})))).then(()=>self.skipWaiting()));
});
self.addEventListener('activate',e=>{
  e.waitUntil(caches.keys().then(ks=>Promise.all(ks.filter(k=>k!==VER).map(k=>caches.delete(k)))).then(()=>self.clients.claim()));
});
self.addEventListener('notificationclick',e=>{
  e.notification.close();
  const cid=e.notification.data&&e.notification.data.cid;
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{
    for(const c of cs){if('focus' in c){c.postMessage({cid});return c.focus()}}
    return self.clients.openWindow('./');
  }));
});
self.addEventListener('push',e=>{
  let p={};try{p=e.data.json()}catch(x){}
  const d=p.data||p.notification||{};if(!d.title)return;
  e.waitUntil(self.clients.matchAll({type:'window',includeUncontrolled:true}).then(cs=>{
    if(cs.some(c=>c.visibilityState==='visible'))return;
    return self.registration.showNotification(d.title,{body:d.body||'',tag:d.cid||'msg',renotify:true,data:{cid:d.cid}});
  }));
});

// تخزين الواجهة والخطوط ومكتبات Firebase للعمل بدون إنترنت (لا نتدخل في طلبات Firestore/Auth)
const CDN=['fonts.googleapis.com','fonts.gstatic.com','www.gstatic.com'];
self.addEventListener('fetch',e=>{
  const r=e.request;if(r.method!=='GET')return;
  const u=new URL(r.url),same=u.origin===self.location.origin;
  if(!same&&!(CDN.includes(u.hostname)&&(u.hostname!=='www.gstatic.com'||u.pathname.startsWith('/firebasejs/'))))return;
  if(r.mode==='navigate'||(same&&(u.pathname==='/'||u.pathname==='/index.html'))){
    e.respondWith((async()=>{
      const cache=await caches.open(VER),cached=await cache.match('/index.html');
      const net=fetch(r).then(res=>{if(res&&res.ok)cache.put('/index.html',res.clone());return res});
      if(!cached)return net;
      return Promise.race([net.catch(()=>cached),new Promise(res=>setTimeout(()=>res(cached),4000))]);
    })());
    return;
  }
  e.respondWith(caches.match(r).then(hit=>{
    const net=fetch(r).then(res=>{if(res&&(res.ok||res.type==='opaque')){const cp=res.clone();caches.open(VER).then(c=>c.put(r,cp))}return res}).catch(()=>hit);
    return hit||net;
  }));
});
